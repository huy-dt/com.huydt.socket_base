package com.huydt.socket_client_base.core;

import com.huydt.socket_client_base.event.ClientEvent;
import com.huydt.socket_client_base.event.ClientEventBus;
import com.huydt.socket_client_base.event.ClientEventType;
import com.huydt.socket_client_base.protocol.InboundMsg;
import com.huydt.socket_client_base.protocol.MsgType;
import com.huydt.socket_client_base.protocol.OutboundMsg;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.json.JSONObject;

import java.net.URI;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * WebSocket client for {@code socket_base} servers.
 *
 * <h3>Minimal usage</h3>
 * <pre>
 * SocketBaseClient client = new SocketBaseClient.Builder()
 *     .host("localhost").port(9001).name("Alice")
 *     .build();
 *
 * client.on(ClientEventType.WELCOME, e ->
 *     System.out.println("Joined! id=" + e.getPlayerId()));
 *
 * client.connect();
 * </pre>
 *
 * <h3>Admin usage</h3>
 * <pre>
 * client.on(ClientEventType.ADMIN_AUTH_OK, e -> {
 *     client.listRooms();
 *     client.kick("playerId", "AFK");
 * });
 * client.adminAuth("mysecret");
 * </pre>
 */
public class SocketBaseClient {

    private final ClientConfig    config;
    private final ClientEventBus  bus;
    private final ClientSession   session;

    private final String          playerName;
    private final String          preferredRoomId;
    private final String          adminToken;       // auto-send ADMIN_AUTH on connect if set
    private final String          initialToken;     // --token CLI flag: reconnect token from a previous session

    private volatile WebSocketClient ws;
    private final    AtomicBoolean   connected       = new AtomicBoolean(false);
    private final    AtomicBoolean   intentionalClose= new AtomicBoolean(false);
    private final    AtomicInteger   reconnectCount  = new AtomicInteger(0);

    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "client-reconnect");
        t.setDaemon(true);
        return t;
    });

    // ── Constructor ───────────────────────────────────────────────────

    protected SocketBaseClient(Builder b) {
        this.config          = b.config;
        this.bus             = new ClientEventBus();
        this.session         = new ClientSession();
        this.playerName      = b.name;
        this.preferredRoomId = b.roomId;
        this.adminToken      = b.adminToken;
        this.initialToken    = b.initialToken;
    }

    // ── Lifecycle ─────────────────────────────────────────────────────

    /**
     * Connect to the server asynchronously.
     * Fires {@link ClientEventType#CONNECTED} on success.
     */
    public void connect() {
        intentionalClose.set(false);
        reconnectCount.set(0);
        doConnect();
    }

    /**
     * Connect synchronously — blocks until connected or timeout.
     * @throws InterruptedException if interrupted
     * @throws java.util.concurrent.TimeoutException if connection takes too long
     */
    public void connectBlocking() throws InterruptedException, TimeoutException {
        CountDownLatch latch = new CountDownLatch(1);
        on(ClientEventType.CONNECTED,    e -> latch.countDown());
        on(ClientEventType.RECONNECT_FAILED, e -> latch.countDown());
        connect();
        int timeout = config.connectTimeoutMs > 0 ? config.connectTimeoutMs : 10_000;
        if (!latch.await(timeout, TimeUnit.MILLISECONDS)) {
            throw new TimeoutException("Connection timed out after " + timeout + "ms");
        }
    }

    /** Disconnect gracefully. Will NOT attempt reconnect. */
    public void disconnect() {
        intentionalClose.set(true);
        scheduler.shutdownNow();
        if (ws != null) ws.close();
    }

    // ── Send raw JSON ─────────────────────────────────────────────────

    /**
     * Send a raw JSON string to the server.
     * @return true if sent, false if not connected
     */
    public boolean send(String json) {
        if (!connected.get() || ws == null) {
            System.err.println("[Client] Cannot send — not connected");
            return false;
        }
        ws.send(json);
        return true;
    }

    // ── Player API ────────────────────────────────────────────────────

    /** Re-send JOIN (useful after manual reconnect). */
    public boolean join(String name) {
        return send(OutboundMsg.join(name, session.getToken(), preferredRoomId));
    }

    /** Join a room. */
    public boolean joinRoom(String roomId) {
        return joinRoom(roomId, null);
    }

    public boolean joinRoom(String roomId, String password) {
        return send(OutboundMsg.joinRoom(roomId, password));
    }

    /** Leave current room. */
    public boolean leaveRoom() {
        return send(OutboundMsg.leaveRoom());
    }

    /** Send a custom application event. */
    public boolean custom(String tag, JSONObject data) {
        return send(OutboundMsg.custom(tag, data));
    }

    public boolean custom(String tag) {
        return custom(tag, null);
    }

    // ── Admin API ─────────────────────────────────────────────────────

    public boolean adminAuth(String token) {
        return send(OutboundMsg.adminAuth(token));
    }

    public boolean kick(String playerId, String reason) {
        return send(OutboundMsg.kick(playerId, reason));
    }

    public boolean ban(String playerId, String reason) {
        return send(OutboundMsg.ban(playerId, reason));
    }

    public boolean unban(String name) {
        return send(OutboundMsg.unban(name));
    }

    public boolean banIp(String ip) {
        return send(OutboundMsg.banIp(ip));
    }

    public boolean unbanIp(String ip) {
        return send(OutboundMsg.unbanIp(ip));
    }

    public boolean getBanList() {
        return send(OutboundMsg.getBanList());
    }

    public boolean createRoom(String name) {
        return send(OutboundMsg.createRoom(name));
    }

    public boolean createRoom(String name, int maxPlayers, String password) {
        return send(OutboundMsg.createRoom(name, maxPlayers, password));
    }

    public boolean closeRoom(String roomId) {
        return send(OutboundMsg.closeRoom(roomId));
    }

    public boolean listRooms() {
        return send(OutboundMsg.listRooms());
    }

    public boolean getRoom(String roomId) {
        return send(OutboundMsg.getRoom(roomId));
    }

    public boolean setRoomState(String roomId, String state) {
        return send(OutboundMsg.setRoomState(roomId, state));
    }

    public boolean adminBroadcast(String roomId, String tag, JSONObject data) {
        return send(OutboundMsg.adminBroadcast(roomId, tag, data));
    }

    public boolean adminSend(String playerId, String tag, JSONObject data) {
        return send(OutboundMsg.adminSend(playerId, tag, data));
    }

    public boolean getStats() {
        return send(OutboundMsg.getStats());
    }

    // ── Event registration ────────────────────────────────────────────

    /** Register an event listener. Returns {@code this} for chaining. */
    public SocketBaseClient on(ClientEventType type,
                               com.huydt.socket_client_base.event.ClientEventListener listener) {
        bus.on(type, listener);
        return this;
    }

    public SocketBaseClient onError(java.util.function.BiConsumer<ClientEvent, Throwable> handler) {
        bus.onError(handler);
        return this;
    }

    // ── Accessors ─────────────────────────────────────────────────────

    public ClientSession getSession()   { return session; }
    public ClientConfig  getConfig()    { return config; }
    public boolean       isConnected()  { return connected.get(); }

    // ── Internal: WebSocket setup ─────────────────────────────────────

    private void doConnect() {
        try {
            URI uri = new URI(config.wsUri());
            ws = new WebSocketClient(uri) {

                @Override
                public void onOpen(ServerHandshake handshake) {
                    connected.set(true);
                    reconnectCount.set(0);
                    System.out.println("[Client] Connected → " + config.wsUri());
                    bus.emit(ClientEvent.of(ClientEventType.CONNECTED, null));

                    // Send ADMIN_AUTH immediately if token provided
                    if (adminToken != null) {
                        send(OutboundMsg.adminAuth(adminToken));
                    }

                    // Send JOIN — prefer CLI --token, then session token (auto-reconnect)
                    String token = (initialToken != null) ? initialToken : session.getToken();
                    send(OutboundMsg.join(playerName, token, preferredRoomId));
                }

                @Override
                public void onMessage(String message) {
                    handleMessage(message);
                }

                @Override
                public void onClose(int code, String reason, boolean remote) {
                    connected.set(false);
                    System.out.printf("[Client] Disconnected (code=%d, reason=%s, remote=%b)%n",
                            code, reason, remote);
                    bus.emit(new ClientEvent.Builder(ClientEventType.DISCONNECTED)
                            .message(reason).build());

                    if (!intentionalClose.get() && config.autoReconnect) {
                        scheduleReconnect();
                    }
                }

                @Override
                public void onError(Exception ex) {
                    System.err.println("[Client] WS error: " + ex.getMessage());
                    bus.emit(ClientEvent.error(ex.getMessage(), ex));
                }
            };

            if (config.connectTimeoutMs > 0) {
                ws.setConnectionLostTimeout(config.connectTimeoutMs / 1000);
            }
            ws.connect();

        } catch (Exception e) {
            bus.emit(ClientEvent.error("Failed to create WebSocket: " + e.getMessage(), e));
        }
    }

    private void scheduleReconnect() {
        int attempt = reconnectCount.incrementAndGet();
        int max     = config.maxReconnectAttempts;

        if (max > 0 && attempt > max) {
            System.err.println("[Client] Max reconnect attempts reached (" + max + ")");
            bus.emit(new ClientEvent.Builder(ClientEventType.RECONNECT_FAILED)
                    .message("Exhausted " + max + " attempts").build());
            return;
        }

        System.out.printf("[Client] Reconnecting in %dms (attempt %d%s)…%n",
                config.reconnectDelayMs, attempt,
                max > 0 ? "/" + max : "");

        bus.emit(new ClientEvent.Builder(ClientEventType.RECONNECTING)
                .message("attempt=" + attempt).build());

        scheduler.schedule(this::doConnect, config.reconnectDelayMs, TimeUnit.MILLISECONDS);
    }

    // ── Message dispatch ──────────────────────────────────────────────

    private void handleMessage(String raw) {
        InboundMsg msg = InboundMsg.parse(raw);
        if (msg == null) {
            System.err.println("[Client] Unparseable message: " + raw);
            return;
        }

        JSONObject payload = msg.getPayload();

        switch (msg.getType()) {

            case WELCOME:
                session.update(payload);
                bus.emit(ClientEvent.of(ClientEventType.WELCOME, payload));
                break;

            case RECONNECTED:
                session.update(payload);
                bus.emit(ClientEvent.of(ClientEventType.RECONNECTED, payload));
                break;

            case ROOM_INFO:
                bus.emit(ClientEvent.of(ClientEventType.ROOM_INFO, payload));
                break;

            case ROOM_LIST:
                bus.emit(ClientEvent.of(ClientEventType.ROOM_LIST, payload));
                break;

            case APP_SNAPSHOT:
                bus.emit(ClientEvent.of(ClientEventType.APP_SNAPSHOT, payload));
                break;

            case ROOM_STATE_CHANGED:
                bus.emit(ClientEvent.of(ClientEventType.ROOM_STATE_CHANGED, payload));
                break;

            case PLAYER_JOINED:
                bus.emit(ClientEvent.of(ClientEventType.PLAYER_JOINED, payload));
                break;

            case PLAYER_LEFT:
                bus.emit(ClientEvent.of(ClientEventType.PLAYER_LEFT, payload));
                break;

            case PLAYER_RECONNECTED:
                bus.emit(ClientEvent.of(ClientEventType.PLAYER_RECONNECTED, payload));
                break;

            case KICKED:
                bus.emit(ClientEvent.of(ClientEventType.KICKED, payload));
                break;

            case BANNED:
                bus.emit(ClientEvent.of(ClientEventType.BANNED, payload));
                break;

            case ADMIN_AUTH_OK:
                session.setAdmin(true);
                bus.emit(ClientEvent.of(ClientEventType.ADMIN_AUTH_OK, payload));
                break;

            case BAN_LIST:
                bus.emit(ClientEvent.of(ClientEventType.BAN_LIST, payload));
                break;

            case STATS:
                bus.emit(ClientEvent.of(ClientEventType.STATS, payload));
                break;

            case CUSTOM_MSG:
                dispatchCustom(msg, payload);
                break;

            case ERROR:
                String code   = payload.optString("code",   "ERROR");
                String detail = payload.optString("detail", "Unknown error");
                System.err.println("[Client] Server error: " + code + " — " + detail);
                bus.emit(new ClientEvent.Builder(ClientEventType.ERROR)
                        .payload(payload).message(code + ": " + detail).build());
                break;

            default:
                System.out.println("[Client] Unhandled type: " + msg.getType());
        }
    }

    /**
     * Override to handle CUSTOM_MSG with your own tag routing.
     *
     * <pre>
     * &#64;Override
     * protected void dispatchCustom(InboundMsg msg, JSONObject payload) {
     *     String tag = payload.optString("tag");
     *     if ("ROUND_START".equals(tag)) { ... }
     * }
     * </pre>
     */
    protected void dispatchCustom(InboundMsg msg, JSONObject payload) {
        bus.emit(ClientEvent.of(ClientEventType.CUSTOM_MSG, payload));
    }

    // ── Builder ───────────────────────────────────────────────────────

    public static class Builder {
        private ClientConfig config      = new ClientConfig.Builder().build();
        private String       name        = "Player";
        private String       roomId      = null;
        private String       adminToken  = null;
        private String       initialToken= null;

        public Builder config(ClientConfig c)   { this.config = c; return this; }
        public Builder host(String host)         { this.config = copyConfig(b -> b.host(host)); return this; }
        public Builder port(int port)            { this.config = copyConfig(b -> b.port(port)); return this; }
        public Builder useSsl(boolean ssl)       { this.config = copyConfig(b -> b.useSsl(ssl)); return this; }
        public Builder name(String name)         { this.name = name; return this; }
        public Builder roomId(String roomId)     { this.roomId = roomId; return this; }

        /** Provide a reconnect token from a previous session (equivalent to --token CLI flag). */
        public Builder reconnectToken(String token)  { this.initialToken = token; return this; }

        /**
         * Provide an admin token — the client will automatically send
         * {@code ADMIN_AUTH} immediately after connecting.
         */
        public Builder adminToken(String token)  { this.adminToken = token; return this; }

        public SocketBaseClient build() { return new SocketBaseClient(this); }

        private ClientConfig copyConfig(java.util.function.Consumer<ClientConfig.Builder> fn) {
            ClientConfig.Builder b = new ClientConfig.Builder()
                    .host(config.host)
                    .port(config.port)
                    .useSsl(config.useSsl)
                    .autoReconnect(config.autoReconnect)
                    .reconnectDelayMs(config.reconnectDelayMs)
                    .maxReconnectAttempts(config.maxReconnectAttempts)
                    .connectTimeoutMs(config.connectTimeoutMs);
            fn.accept(b);
            return b.build();
        }
    }
}
