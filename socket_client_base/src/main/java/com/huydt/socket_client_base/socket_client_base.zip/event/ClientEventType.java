package com.huydt.socket_client_base.event;

/**
 * All events the client can emit to registered listeners.
 */
public enum ClientEventType {

    // ── Connection lifecycle ──────────────────────────────────────────
    CONNECTED,          // socket connected, before JOIN sent
    DISCONNECTED,       // socket dropped
    RECONNECTING,       // about to attempt reconnect
    RECONNECT_FAILED,   // all retries exhausted

    // ── Session ───────────────────────────────────────────────────────
    WELCOME,            // server accepted our JOIN — we have playerId + token
    RECONNECTED,        // server accepted our reconnect token

    // ── Room ─────────────────────────────────────────────────────────
    ROOM_INFO,          // full room snapshot received
    ROOM_LIST,          // room list received
    ROOM_STATE_CHANGED, // room state updated
    PLAYER_JOINED,      // another player joined our room
    PLAYER_LEFT,        // another player left our room
    PLAYER_RECONNECTED, // a ghost player reconnected

    // ── Lobby ─────────────────────────────────────────────────────────
    APP_SNAPSHOT,       // full players[] + rooms[] broadcast

    // ── Admin ─────────────────────────────────────────────────────────
    ADMIN_AUTH_OK,
    STATS,
    BAN_LIST,

    // ── Moderation ───────────────────────────────────────────────────
    KICKED,
    BANNED,

    // ── Custom / misc ─────────────────────────────────────────────────
    CUSTOM_MSG,         // server forwarded a CUSTOM_MSG
    ERROR,              // server sent ERROR or local exception
}
