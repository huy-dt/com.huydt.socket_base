package com.huydt.socket_client_base.core;

import org.json.JSONObject;

/**
 * Holds the client's server-issued identity after a successful JOIN.
 * Persisted across reconnects via the reconnect token.
 */
public final class ClientSession {

    private String     playerId;
    private String     token;       // reconnect token — keep secret
    private String     name;
    private String     roomId;
    private boolean    isAdmin;
    private JSONObject playerJson;  // full player snapshot from WELCOME
    private JSONObject roomJson;    // full room snapshot from WELCOME (may be null)

    ClientSession() {}

    // ── Update from WELCOME / RECONNECTED payload ─────────────────────

    public void update(JSONObject payload) {
        JSONObject player = payload.optJSONObject("player");
        if (player != null) {
            this.playerJson = player;
            this.playerId   = player.optString("id",      playerId);
            this.token      = player.optString("token",   token);
            this.name       = player.optString("name",    name);
            this.roomId     = player.optString("roomId",  null);
            this.isAdmin    = player.optBoolean("isAdmin", false);
        }
        JSONObject room = payload.optJSONObject("room");
        if (room != null && !room.equals(JSONObject.NULL)) {
            this.roomJson = room;
            this.roomId   = room.optString("id", roomId);
        }
    }

    public void setRoomId(String roomId) { this.roomId = roomId; }
    public void setAdmin(boolean admin)  { this.isAdmin = admin; }

    // ── Accessors ─────────────────────────────────────────────────────

    public String     getPlayerId()  { return playerId; }
    public String     getToken()     { return token; }
    public String     getName()      { return name; }
    public String     getRoomId()    { return roomId; }
    public boolean    isAdmin()      { return isAdmin; }
    public boolean    isLoggedIn()   { return playerId != null; }
    public JSONObject getPlayerJson(){ return playerJson; }
    public JSONObject getRoomJson()  { return roomJson; }

    @Override
    public String toString() {
        return "Session{id=" + playerId + ", name=" + name
               + ", room=" + roomId + ", admin=" + isAdmin + "}";
    }
}
