package com.huydt.socket_client_base.core;

/**
 * Immutable configuration for {@link SocketBaseClient}.
 *
 * <pre>
 * ClientConfig config = new ClientConfig.Builder()
 *     .host("localhost")
 *     .port(9001)
 *     .autoReconnect(true)
 *     .reconnectDelayMs(2000)
 *     .maxReconnectAttempts(5)
 *     .build();
 * </pre>
 */
public final class ClientConfig {

    public final String  host;
    public final int     port;
    public final boolean useSsl;

    /** Automatically attempt to reconnect on disconnect. */
    public final boolean autoReconnect;

    /** Delay between reconnect attempts in ms. */
    public final int     reconnectDelayMs;

    /** Max reconnect attempts. 0 = unlimited. */
    public final int     maxReconnectAttempts;

    /** Timeout waiting for a server response in ms. 0 = no timeout. */
    public final int     connectTimeoutMs;

    private ClientConfig(Builder b) {
        this.host                 = b.host;
        this.port                 = b.port;
        this.useSsl               = b.useSsl;
        this.autoReconnect        = b.autoReconnect;
        this.reconnectDelayMs     = b.reconnectDelayMs;
        this.maxReconnectAttempts = b.maxReconnectAttempts;
        this.connectTimeoutMs     = b.connectTimeoutMs;
    }

    public String wsUri() {
        return (useSsl ? "wss" : "ws") + "://" + host + ":" + port;
    }

    @Override
    public String toString() {
        return String.format(
            "ClientConfig{uri=%s, autoReconnect=%b, reconnectDelay=%dms, maxAttempts=%s}",
            wsUri(), autoReconnect, reconnectDelayMs,
            maxReconnectAttempts == 0 ? "∞" : maxReconnectAttempts);
    }

    // ── Builder ───────────────────────────────────────────────────────

    public static class Builder {
        private String  host                 = "localhost";
        private int     port                 = 9001;
        private boolean useSsl               = false;
        private boolean autoReconnect        = true;
        private int     reconnectDelayMs     = 2_000;
        private int     maxReconnectAttempts = 0;      // unlimited
        private int     connectTimeoutMs     = 5_000;

        public Builder host(String host)                         { this.host = host; return this; }
        public Builder port(int port)                            { this.port = port; return this; }
        public Builder useSsl(boolean ssl)                       { this.useSsl = ssl; return this; }
        public Builder autoReconnect(boolean v)                  { this.autoReconnect = v; return this; }
        public Builder reconnectDelayMs(int ms)                  { this.reconnectDelayMs = ms; return this; }
        public Builder maxReconnectAttempts(int n)               { this.maxReconnectAttempts = n; return this; }
        public Builder connectTimeoutMs(int ms)                  { this.connectTimeoutMs = ms; return this; }

        public ClientConfig build() { return new ClientConfig(this); }
    }
}
